package com.cucumber;

import com.cucumber.commonservices.ExcelHelper;
import com.cucumber.pages.LoginScenarioOutlinePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

public class ExcelData {

    ExcelHelper excel;
    String actual;
    LoginScenarioOutlinePage login;

    public ExcelData() {
        excel = new ExcelHelper();
        login = new LoginScenarioOutlinePage();
    }


    @Then("I should see dashboard")
    public void iShouldSeeDashboard() {

    }

    @When("read from excel")
    public void readFromExcel() {
        XSSFSheet sheet = excel.getExcelSheetTabData("D:\\Excel_TestData.xlsx", "Excel_TestData", "Sheet1");
        actual = sheet.getRow(1).getCell(1).getStringCellValue();

        int rowsCount = sheet.getPhysicalNumberOfRows();
        System.out.println(rowsCount);

        String email;
        String password;
        for (int i = 1; i < rowsCount; i++) {
            email = sheet.getRow(i).getCell(1).getStringCellValue();
            login.enter_email(email);
            password = sheet.getRow(i).getCell(2).getStringCellValue();
            login.enter_password(password);

        }
    }

    @Then("data should display from excel")
    public void dataShouldDisplayFromExcel() {
        Assert.assertEquals(actual,"123raj@gmail.com");
    }

    @When("write to excel")
    public void writeToExcel() {

    }

    @Then("data should display")
    public void dataShouldDisplay() {
    }
}
