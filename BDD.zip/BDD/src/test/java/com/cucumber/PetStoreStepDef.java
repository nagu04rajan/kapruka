package com.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class PetStoreStepDef {

    Response response;
    private Map<String, Object> requestBody;
    public String baseURI;


    @Given("I set the Pet Store user creation endpoint")
    public void iSetThePetStoreUserCreationEndpoint() {
        baseURI = "https://petstore.swagger.io/v2/user";
    }


    @When("I create a user with the following details")
    public void iCreateAUserWithTheFollowingDetails(io.cucumber.datatable.DataTable dataTable) {
        requestBody = new HashMap<>();
        Map<String, String> data = dataTable.asMap(String.class, String.class);

        requestBody.put("id", Integer.parseInt(data.get("id")));
        requestBody.put("username", data.get("username"));
        requestBody.put("firstName", data.get("firstName"));
        requestBody.put("lastName", data.get("lastName"));
        requestBody.put("email", data.get("email"));
        requestBody.put("password", data.get("password"));
        requestBody.put("phone", data.get("phone"));
        requestBody.put("userStatus", Integer.parseInt(data.get("userStatus")));

        response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post(baseURI);
    }

    @Then("check if the response status code is shown as {int}")
    public void checkIfTheResponseStatusCodeIsShownAs(int exp_StatusCode) {
        int actualStatusCode = response.getStatusCode();
        Assert.assertEquals(exp_StatusCode,actualStatusCode);
        System.out.println(exp_StatusCode + " " +  actualStatusCode);
    }
}
