package com.cucumber;

import com.cucumber.pages.SearchFuncPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchFunStepDef {

    SearchFuncPage searchfunc;

    public SearchFunStepDef()
    {
        searchfunc = new SearchFuncPage();
    }



    @Then("the user gives {string}")
    public void theUserGives(String productName)  {
        searchfunc.searchbar(productName);
    }

    @When("the user clicks on search")
    public void theUserClicksOnSearch() throws InterruptedException {
        searchfunc.search_btn();
    }

    @When("the user gives the credentials")
    public void theUserGivesTheCredentials() throws InterruptedException {
        searchfunc.user_credentials();
    }

    @When("the user clicks on logout button")
    public void theUserCliksOnLogoutButton() throws InterruptedException {
        searchfunc.logOutBtn();
    }

    @Then("the user clicks on the profile icon")
    public void theUserClicksOnTheProfileIcon() throws InterruptedException {
        searchfunc.profileButtonCheck();
    }
}
