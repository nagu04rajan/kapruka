package com.cucumber;

import com.cucumber.pages.DynamicTablePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DynamicTableStepDef {

    DynamicTablePage dynTblPg;

    public DynamicTableStepDef()
    {
        dynTblPg = new DynamicTablePage();
    }



    @Then("the user clicks ENTER button")
    public void theUserClicksENTERButton() throws InterruptedException {
        dynTblPg.enterButton();

    }


    @Then("the user scrolls down till the dynamic table")
    public void theUserScrollsDownTillTheDynamicTable() throws InterruptedException {
        dynTblPg.scrollingDownSpecificElement();
    }


    @When("the user selects required values from table")
    public void theUserSelectsRequiredValuesFromTable() throws InterruptedException {
        dynTblPg.dynamicTableRowsSelection();
    }
}
