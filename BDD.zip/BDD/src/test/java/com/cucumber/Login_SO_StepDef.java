package com.cucumber;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.cucumber.commonbase.Base;
import com.cucumber.commonservices.ScreenshotServices;
import com.cucumber.commonvalidation.ComValidation;
import com.cucumber.pages.KaprukaAccountCreationPage;
import com.cucumber.pages.LoginScenarioOutlinePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Login_SO_StepDef extends Base {

    LoginScenarioOutlinePage loginPage;
    
    WebDriver driver;
    ScreenshotServices services;
    
    public Login_SO_StepDef()
    {
        loginPage = new LoginScenarioOutlinePage();
        services=new ScreenshotServices();
    }

    @Then("the user clicks on profile icon")
    public void theUserClicksOnProfileIcon() {
        loginPage.profile_icon_click();
    }



    @When("the user gives the username {string} and password {string}")
    public void theUserGivesTheUsernameAndPassword(String email, String password) {
        loginPage.enter_email(email);
        loginPage.enter_password(password);
    }

    @Then("the user clicks on the login button")
    public void theUserClicksOnTheLoginButton()
    {
        loginPage.submit_button();


        try {
            System.out.println("Dashboard");
            String actualTitle = loginPage.getTitle();
            String expectedTitle = "Account Login / New Account Creation";
            Assert.assertEquals(actualTitle, expectedTitle, "Title dont match");

        }
        catch (Exception e)
        {
            ExtentCucumberAdapter.getCurrentStep().fail(e.getMessage());
            scenario.attach(services.getScreenshot(), ComValidation.IMAGEPNG,scenario.getName());
        }
    }



    @Then("the account creation error message should be displayed")
    public void theAccountCreationErrorMessageShouldBeDisplayed() {
        loginPage.error_msg_print();
    }
}
