package com.cucumber;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import static io.restassured.RestAssured.given;

public class API_ReqresStepDef {

    Response response;

    @Given("the user sets the baseURI for JSONPlaceholder for reqres portal")
    public void theUserSetsTheBaseURIForJSONPlaceholderForReqresPortal() {
        RestAssured.baseURI = "https://reqres.in";
    }


    @And("check if the response should contain id as {int}")
    public void checkIfTheResponseShouldContainIdAs(int expectedID) {
        Response response = given().when().get("/api/users/2");
        int actID = response.jsonPath().getInt("data.id");
        Assert.assertEquals(expectedID,actID);
        System.out.println(expectedID + " " +  actID);
    }

    @And("check if the response should contain first_name as {string};")
    public void checkIfTheResponseShouldContainFirst_nameAs(String expectedFirstName) {
        Response response = given().when().get("/api/users/2");
        String actualFirstName = response.jsonPath().getString("data.first_name");
        Assert.assertEquals(expectedFirstName,actualFirstName);
        System.out.println(expectedFirstName + " " +  actualFirstName);

    }
}
