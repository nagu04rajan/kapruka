package com.cucumber;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

public class APIStepDef {

    Response response;

    @Given("the user sets the baseURI for JSONPlaceholder")
    public void theUserSetsTheBaseURIForJSONPlaceholder() {

    RestAssured.baseURI = "https://jsonplaceholder.typicode.com/";

    }

    @When("send the GET request to {string}")
    public void sendTheGETRequestTo(String endpoint) {
        response = RestAssured.given().when().get(endpoint);
    }


    @Then("check if the response status code is {int}")
    public void checkIfTheResponseStatusCodeIs(int exp_StatusCode) {
        int actualStatusCode = response.getStatusCode();
        Assert.assertEquals(exp_StatusCode,actualStatusCode);
        System.out.println(exp_StatusCode + " " +  actualStatusCode);
    }

    @And("check if the response should contain userID as {int}")
    public void checkIfTheResponseShouldContainUserIDAs(int exp_userID) {
        int actualUserID = response.jsonPath().getInt("userId");
        Assert.assertEquals(exp_userID,actualUserID);
        System.out.println(exp_userID + " " +  actualUserID);

    }
}
