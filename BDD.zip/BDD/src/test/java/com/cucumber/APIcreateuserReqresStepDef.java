package com.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import java.util.HashMap;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class APIcreateuserReqresStepDef {

    Response response;

    @Given("the user sets the baseURI for reqres portal")
    public void theUserSetsTheBaseURIForReqresPortal() {
        baseURI = "https://reqres.in/api/users";

    }

    @When("the user is created with name and job details with post request")
    public void theUserIsCreatedWithNameAndJobDetailsWithPostRequest() {

        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put("name", "John");
        userDetails.put("job", "QA Engineer");

        response = given().header("Content-Type","application/json")
                .body(userDetails).when().post(baseURI);

    }

    @Then("check if the response for the status code is {int}")
    public void checkIfTheResponseForTheStatusCodeIs(int exp_StatusCode) {

//        Response response = given().when().get("/api/users");
        int actualStatusCode = response.getStatusCode();
        Assert.assertEquals(exp_StatusCode,actualStatusCode);
        System.out.println(exp_StatusCode + " " +  actualStatusCode);

    }
}
