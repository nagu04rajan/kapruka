package com.cucumber;

import com.cucumber.pages.PDFsearchPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PDF_SearchFunc_StepDef {

    PDFsearchPage pdf;

    public PDF_SearchFunc_StepDef()
    {
        pdf  = new PDFsearchPage();
    }

    @Then("the user clicks on the search bar")
    public void theUserClicksOnTheSearchBar() {
        pdf.searchBox();
    }

    @When("the user searches for {string}")
    public void theUserSearchesFor(String arg0) {

    }

    @Then("the user clicks on search button")
    public void theUserClicksOnSearchButton() {
        pdf.searchButtonClick();
    }
}
