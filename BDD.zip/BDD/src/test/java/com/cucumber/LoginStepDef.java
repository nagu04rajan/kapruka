package com.cucumber;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.cucumber.commonbase.Base;
import com.cucumber.commonservices.ScreenshotServices;
import com.cucumber.commonvalidation.ComValidation;
import com.cucumber.pages.KaprukaAccountCreationPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;


public class LoginStepDef extends Base{

        KaprukaAccountCreationPage accountCreation;
        WebDriver driver;
        ScreenshotServices services;

        public LoginStepDef(){

            accountCreation = new KaprukaAccountCreationPage(); // we are creating object for the page name
            driver = Hooks.driver;
            services=new ScreenshotServices();
        }

//        @When("I login with the website")
//        public void login() {
//
//            accountCreation.browser_setup();
//
//
//        }
//
//    @Then("I should see dashboard")
//    public void iShouldSeeDashboard() {
//
//            accountCreation.Account_icon();
//            accountCreation.create_account();
//    }
// Starting new series. Ignore the above one

    @When("the URL is launched")
    public void theURLIsLaunched() {
        accountCreation.browser_setup();
    }

    @Then("create account button should be displayed")
    public void createAccountButtonShouldBeDisplayed() {
            accountCreation.Account_icon();
            accountCreation.create_button_gettext();

    }

    @When("click on create account")
    public void clickOnCreateAccount() {

        try {
            System.out.println("Dashboard");
            String actualTitle = KaprukaAccountCreationPage.driver.getTitle();
            String expectedTitle = "New Account Creation";

        }
        catch (Exception e)
        {
            ExtentCucumberAdapter.getCurrentStep().fail(e.getMessage());
            scenario.attach(services.getScreenshot(), ComValidation.IMAGEPNG,scenario.getName());
        }

    }

    @Then("user enters valid credentials")
    public void userEntersValidCredentials() {
    }
}

