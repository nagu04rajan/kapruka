package com.cucumber;

import com.cucumber.pages.TernaryOperatorPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TernaryOpStepDef {

    TernaryOperatorPage topg;

    public TernaryOpStepDef()
    {
        topg = new TernaryOperatorPage();
    }

    @When("the user searches for chocolates")
    public void theUserSearchesForChocolates() throws InterruptedException {

        topg.searchItems();

    }

    @When("the user validates the page title")
    public void theUserValidatesThePageTitle() {
        topg.titleValidation();
    }

    @Then("the user clicks on search bar area")
    public void theUserClicksOnSearchBarArea() throws InterruptedException {
        topg.searchBarArea();
    }
}
