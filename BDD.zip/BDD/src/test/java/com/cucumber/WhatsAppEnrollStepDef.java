package com.cucumber;

import com.cucumber.commonbase.Base;
import com.cucumber.pages.WhatsAppEnrollmentPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WhatsAppEnrollStepDef extends Base {

    WhatsAppEnrollmentPage whatsapp;

    public WhatsAppEnrollStepDef() {
        whatsapp = new WhatsAppEnrollmentPage();

    }
    @When("the user launches the browser and URL")
    public void theUserLaunchesTheBrowserAndURL() {
        whatsapp.browserAndURLSetup();
    }

    @Then("the user navigates to chocolate page")
    public void theUserNavigatesToChocolatePage() throws InterruptedException {
        whatsapp.writeTextBox();
    }



    @When("the user scrolls down till the end")
    public void theUserScrollsDownTillTheEnd() throws InterruptedException {

        whatsapp.scrollingDown();
    }

    @Then("the user verifies the whatsapp button and clicks the button")
    public void theUserVerifiesTheWhatsappButtonAndClicksTheButton() throws InterruptedException {

        whatsapp.clickingButton();
    }

    @When("the user is taken to the community page")
    public void theUserIsTakenToTheCommunityPage() throws InterruptedException {
        whatsapp.titleDisplay();
    }

    @And("the browser gets closed")
    public void theBrowserGetsClosed() {
        whatsapp.quitDriver();
    }


}
