package com.cucumber;

import java.util.HashMap;

public class HashmapStepDef {

    public static void main(String[] args) {
        HashMap<Integer, String> empDetails = new HashMap<>();

        empDetails.put(1, "John");
        empDetails.put(2, "Raj");
        empDetails.put(3, "Tom");

        System.out.println(empDetails.get(1));

    }

}

