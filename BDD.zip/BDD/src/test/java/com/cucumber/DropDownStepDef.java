package com.cucumber;

import com.cucumber.pages.DropDownPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static com.cucumber.commonbase.Base.driver;

public class DropDownStepDef {

    DropDownPage drpdwnpage;

    public DropDownStepDef()
    {
        drpdwnpage = new DropDownPage();
    }

    @Then("the user clicks on the language dropdown")
    public void theUserClicksOnTheLanguageDropdown() throws InterruptedException {
        drpdwnpage.dropDownClick();
    }

    @When("the user selects tamil as language")
    public void theUserSelectsTamilAsLanguage() {
        drpdwnpage.langSelect();

    }

    @Then("the user selects english as language")
    public void theUserSelectsEnglishAsLanguage() {
    }
}
