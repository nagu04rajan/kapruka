package commoncontrols;

import com.cucumber.commonbase.Base;

public class WebTextBox extends Base {


}
