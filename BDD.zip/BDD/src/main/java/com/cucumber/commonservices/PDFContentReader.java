package com.cucumber.commonservices;

import com.cucumber.commonbase.Base;

public class PDFContentReader extends Base {

    // perform search func. using PDF File Reader
}
