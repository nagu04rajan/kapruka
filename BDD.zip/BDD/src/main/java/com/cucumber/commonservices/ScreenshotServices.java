package com.cucumber.commonservices;

import com.aventstack.extentreports.gherkin.model.Scenario;
import com.cucumber.commonbase.Base;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class ScreenshotServices extends Base {

    public static Scenario scenario;


    public byte[] getScreenshot() {
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        byte[] screenshotBytes = screenshot.getScreenshotAs(OutputType.BYTES);
        return screenshotBytes;
    }

}
