package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.time.Duration;

public class KaprukaAccountCreationPage extends Base {

    private final By profile_icon = By.xpath("//*[@alt='Account Icon']");
    private final By create_account_btn = By.xpath("(//button[@type='button'])[2]");


    public void browser_setup() {
        driver.get("https://www.kapruka.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
//        driver.findElement(profile_icon).click();
    }

    public void Account_icon() {
        WebElement account_icon = driver.findElement(profile_icon);
        account_icon.click();

    }

    public void create_button_gettext()
    {
        WebElement create_account_btn_text_validation = driver.findElement(create_account_btn);
        System.out.println(create_account_btn_text_validation.getText());

    }

    public void create_account() {
        WebElement profile_icon_click = driver.findElement(By.xpath("(//button[@type='button'])[2]"));
        profile_icon_click.click();

        WebElement first_name = driver.findElement(By.xpath("//input[@name='firstName']"));
        first_name.sendKeys("Nagarajan");

        WebElement last_name = driver.findElement(By.xpath("//input[@name='lastName']"));
        last_name.sendKeys("Iyer");

        WebElement e_mail_address = driver.findElement(By.name("email"));
        e_mail_address.sendKeys("Nagarajan");

        WebElement create_pwd = driver.findElement(By.name("password"));
        create_pwd.sendKeys("Naga@1234");

        WebElement confirm_pwd = driver.findElement(By.name("passwordReConfirm"));
        confirm_pwd.sendKeys("Naga@1234");

    }

    public void submit_form() {
        WebElement create_account_submit_button = driver.findElement(By.xpath("//button[@onclick='checkForm();']"));
        create_account_submit_button.click();
    }


}
