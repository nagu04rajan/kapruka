package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class TernaryOperatorPage extends Base {

    public void searchItems() throws InterruptedException {
        driver.findElement(By.id("search_bar_id")).sendKeys("chocolates");
//        driver.findElement(By.id("search_bar_id")).sendKeys("shirts");
        driver.findElement(By.id("search_bar_id")).sendKeys(Keys.ENTER);
        Thread.sleep(5000);
    }

    public void searchBarArea() throws InterruptedException {
        driver.findElement(By.id("search_bar_id")).click();
        Thread.sleep(3000);
    }

    public void titleValidation()
    {
//        String pageTitle = driver.getTitle();
//        System.out.println("Page Title: "+pageTitle);

        String expectedTitle = "Delicious Cakes for Every Celebration at Lowest Prices | Price in Sri Lanka";
        String actualTitle = driver.getTitle();
        String result = actualTitle.equals(expectedTitle) ? "Awesome, your test passed" : "Oops Failed";
        System.out.println(result);
    }

}
