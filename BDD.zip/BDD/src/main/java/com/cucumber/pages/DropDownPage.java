package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DropDownPage extends Base {

    private final By langDrpDwn = By.xpath("//select[@aria-label='Select language']");

    public void dropDownClick() throws InterruptedException {
        driver.findElement(langDrpDwn).click();
        Thread.sleep(5000);
    }

    public void langSelect()
    {
        WebElement dropdownElement = driver.findElement(langDrpDwn);
        Select dropdown = new Select(dropdownElement);
        dropdown.selectByIndex(1);
    }

}
