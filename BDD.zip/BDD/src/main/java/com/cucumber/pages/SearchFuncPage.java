package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import io.cucumber.java.en_old.Ac;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class SearchFuncPage extends Base {

    private final By search_bar = By.id("search_bar_id");
    private final By search_button = By.xpath("//img[@alt='Search']");
    private final By userName = By.name("email");
    private final By password = By.name("password");
    private final By loginBtn = By.name("Login");
    private final By logoutBtns = By.xpath("//div[contains(text(),'Logout')]");
    private final By profileIconBtn = By.xpath("//a[@aria-label='Login to Your Account']");

    public void searchbar(String productName) {
        driver.findElement(search_bar).sendKeys(productName);

        Actions action = new Actions(driver);
        WebElement searchBtn = driver.findElement(search_bar);
        action.moveToElement(searchBtn).sendKeys(Keys.ENTER).perform();
    }

    public void profileButtonCheck() throws InterruptedException {
        driver.findElement(profileIconBtn).click();
        Thread.sleep(5000);
    }

    public void search_btn() throws InterruptedException {
        driver.findElement(search_button).click();
        Thread.sleep(5000);  // to see whether the page is uploading
    }

    public void logOutBtn() throws InterruptedException {
        driver.findElement(logoutBtns).click();
        Thread.sleep(4000);
//        System.out.println("You are logged off");

    }

    public void user_credentials() throws InterruptedException {
        driver.findElement(userName).sendKeys("nagu@123.com");
        driver.findElement(password).sendKeys("nagu");
        driver.findElement(loginBtn).click();
        Thread.sleep(3000);
    }
}
