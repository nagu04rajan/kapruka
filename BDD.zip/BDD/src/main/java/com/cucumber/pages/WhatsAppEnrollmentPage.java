package com.cucumber.pages;

import com.beust.ah.A;
import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;

public class WhatsAppEnrollmentPage extends Base {

    private final By sendKeys_text = By.xpath("//input[@id='search_bar_id']");
    private final By channelButton = By.xpath("//span[contains(text(),'Join Our Whatsapp Channel')]");
    private final By searchButton = By.id("search_btn");

    public void browserAndURLSetup() {
        driver.get("https://www.kapruka.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
    }


    public void writeTextBox() throws InterruptedException {
        driver.findElement(sendKeys_text).sendKeys("chocolate");
        driver.findElement(searchButton).click();
//        Actions mouse_enter = new Actions(driver);
//        mouse_enter.moveToElement((WebElement) sendKeys_text).sendKeys(Keys.ENTER).perform();

        Thread.sleep(5000);
    }

    public void scrollingDown() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement channelBox = driver.findElement(By.xpath("//span[contains(text(),'Join Our Whatsapp Channel')]"));
        js.executeScript("arguments[0].scrollIntoView(true);",channelBox);
        Thread.sleep(2000);
    }

    public void clickingButton() throws InterruptedException {
        driver.findElement(channelButton).click();
        Thread.sleep(3000);
    }

    public void titleDisplay() throws InterruptedException {
        driver.getTitle();
        Thread.sleep(2000);
    }

    public void quitDriver()
    {
        driver.quit();
    }

}
