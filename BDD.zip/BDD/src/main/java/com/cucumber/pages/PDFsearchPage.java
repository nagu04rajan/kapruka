package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;

public class PDFsearchPage extends Base {

    private final By searchboxInput = By.id("search_bar_id");
    private final By searchBoxButton = By.id("search_btn");

    public void searchBox()
    {
        driver.findElement(searchboxInput).click();
    }

    public void searchButtonClick()
    {
        driver.findElement(searchBoxButton);
    }



}
