package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

public class DynamicTablePage extends Base {

    public void enterButton() throws InterruptedException {
        driver.findElement(By.id("search_bar_id")).sendKeys(Keys.ENTER);
        Thread.sleep(3000);

    }


    public void scrollingDownSpecificElement() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement dynamicTable = driver.findElement(By.xpath("//div[@class='headingCommon']"));
        js.executeScript("arguments[0].scrollIntoView(true);", dynamicTable);
        Thread.sleep(3000);

    }

    public void dynamicTableRowsSelection() throws InterruptedException {
        List<WebElement> allProductsName = driver.findElements(By.xpath("//div[@class='Rebrand_table space-bot']/table/tbody/tr/td[1]"));
        System.out.println("The size of the allProductsName are: " + allProductsName.size());

        List<WebElement> allProductsPrice = driver.findElements(By.xpath("//div[@class='Rebrand_table space-bot']/table/tbody/tr/td[2]"));
        System.out.println("The size of the allProductsPrice are: " + allProductsPrice.size());

        String expectedResult = "Mila Oversized Shirt -Sky";


        Thread.sleep(3000);

        for (int i = 0; i < allProductsName.size(); i++) {
            if (allProductsName.get(i).getText().equalsIgnoreCase(expectedResult)) {
                System.out.println(allProductsName.get(i).getText() + " &  " + allProductsPrice.get(i).getText());
                Thread.sleep(2000);

            }
        }
    }

}
