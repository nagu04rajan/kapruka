package com.cucumber.pages;

import com.cucumber.commonbase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginScenarioOutlinePage extends Base {

    private final By enter_email_id = By.xpath("//input[@type='email']");
    private final By enter_password = By.xpath("//input[@type='password']");
    private final By profile_icon = By.xpath("//*[@alt='Account Icon']");
    private final By submit_btn = By.xpath("//input[@type='submit']");


    public void profile_icon_click() {

        driver.findElement(profile_icon).click();
    }

    public void enter_email(String email) {
        driver.findElement(enter_email_id).sendKeys(email);

    }

    public void enter_password(String password) {
        driver.findElement(enter_password).sendKeys(password);
    }

    public void submit_button() {
        driver.findElement(submit_btn).click();


    }

    public String actualResult() {
        WebElement act_res = driver.findElement(By.xpath("//font[contains(text(),'Your')]"));
        act_res.getText();
        return null;
    }

    public String getTitle()
    {
        return driver.getTitle();

    }


    public void error_msg_print() {
        WebElement error_pass_incorr = driver.findElement(By.xpath("//font[contains(text(),'Your password is wrong. Please try again.')]"));
        String abc = error_pass_incorr.getText();
        System.out.println(abc);
    }


}

